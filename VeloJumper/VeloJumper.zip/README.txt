VeloJumper is a game in which you inherit your platform's velocity when you jump from it, and try to climb to the top-most platform.
It has only 3 colors, uses only 1 button (any of your choosing will work), and has no GUI/HUD.

To play, navigate to the folder of your operating system, and run the executeable. 